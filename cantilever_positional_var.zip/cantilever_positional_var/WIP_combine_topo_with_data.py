
import re
import os
import math
import traceback
import subprocess
from itertools import combinations

atomcount = 996 #just for testing since this is a varible in the mmptolammps script

Add_Topology = 1

#out_dir='C:/Users/Tom/Desktop/Blender Game Engine/assembly_test' # You can use forward slashes on Windows
out_dir="C:/LAMMPS/cantilever_positional_var/" # You can use forward slashes on Windows
data_file_out='temp' #this is a file that holds all the atoms before the header info is written to the final file which is another name down below
output_data=os.path.join(out_dir,data_file_out)
data_file_name = os.path.join(out_dir,"cantilever_positional_var.data")
mmp_file = "C:/LAMMPS/cantilever_positional_var/cantilever_positional_var.mmp"
input_file = open(mmp_file, 'r') 


if Add_Topology == 1:  
    print("adding topology to data file")
    #subprocess.run(["python", "add_lammps_bonds_7.py", out_dir, mmp_file]) #might have to wait until this finishes for the rest to work
    
    #get the number of bonds
    bonds = open(out_dir+"Bonds.txt", 'r')
    igot_b = bonds.readlines()
    number_bonds = igot_b[-1].split()[0]
    print("number of bonds", number_bonds)
    bonds.close()
    #get number of angles
    angles = open(out_dir+"Angles_numbered.txt", 'r')
    igot_a = angles.readlines()
    number_angles = igot_a[-1].split()[0]
    print("number of angles", number_angles)
    angles.close()
    
    num_bonds_line = 3
    num_angles_line = 4
    bond_coef_line = 7
    angle_coef_line = 8
    #foo = "C:/LAMMPS/cantilever_positional_var/cantilever_positional_var.data"
    
   
    file_path = "C:/LAMMPS/cantilever_positional_var/cantilever_positional_var.data"
    bond_path = "C:/LAMMPS/cantilever_positional_var/Bonds.txt"
    angle_path = "C:/LAMMPS/cantilever_positional_var/Angles_numbered.txt"

    
    with open(file_path, 'r') as file:
        lines = file.readlines()
        
    #insert the number of bonds
    bond_number_str = str(number_bonds)+" "+"bonds" + "\n"
    lines.insert(num_bonds_line, bond_number_str )
    #insert number of angles with carrage return after
    angle_number_str = str(number_angles)+" "+"angles" +"\n"
    lines.insert(num_angles_line, angle_number_str )
    
    #insert number of bond and angle coeffients 
    bond_coef_str =" "+ "2 bond types" + "\n" # needs to be changed it there are no hydrogen, eventually it should count the number in the bonds list
    lines.insert(bond_coef_line, bond_coef_str )
   
    angle_coef_str =" "+ "3 angle types"  +"\n"  # needs to be changed it there are no hydrogen, eventually it should count the number in the angles list
    lines.insert(angle_coef_line , angle_coef_str )    
        
    with open(file_path, 'w') as file:
        file.writelines(lines)   
        
    with open(file_path, 'a') as file:
        blank_line = '\n'
        
        file.writelines(blank_line)
        file.writelines(" Bonds")   
        file.writelines(blank_line)
        file.writelines(blank_line)
        with open(bond_path, 'r') as bond_file:
            bonds = bond_file.readlines()
            for bond in bonds:
                file.writelines(bond)
      
        #angles section
        file.writelines(blank_line)
        file.writelines(blank_line)       
        
        file.writelines(blank_line)
        file.writelines(" Angles")   
        file.writelines(blank_line)
        file.writelines(blank_line)
        with open(angle_path, 'r') as angles_file:
            angles= angles_file.readlines()
            for angle in angles:
                file.writelines(angle)    

print("LAMMPS DATA FILE COMPLETED. CHECK THE BOX SIZE")